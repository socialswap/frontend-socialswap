import React, { useState } from 'react';

const Process = () => {
  const [isOpen, setIsOpen] = useState({
    step1: false,
    step2: false,
    step3: false,
  });

  const [selectedCategory, setSelectedCategory] = useState('buyers');

  const toggleStep = (step) => {
    setIsOpen({ ...isOpen, [step]: !isOpen[step] });
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    // Reset all steps when switching categories
    setIsOpen({
      step1: false,
      step2: false,
      step3: false,
    });
  };

  const renderSteps = () => {
    if (selectedCategory === 'buyers') {
      return (
        <>
          <div className="step" onClick={() => toggleStep('step1')}>
            <div className="step-header">
              <h3>Buyer Step-1</h3>
              <span className={`arrow ${isOpen.step1 ? 'open' : 'close'}`}></span>
            </div>
            {isOpen.step1 && (
              <div className="step-content">
                {/* Add content for Buyer's Step 1 here */}
              </div>
            )}
          </div>
          <div className="step" onClick={() => toggleStep('step2')}>
            <div className="step-header">
              <h3>Buyer Step-2</h3>
              <span className={`arrow ${isOpen.step2 ? 'open' : 'close'}`}></span>
            </div>
            {isOpen.step2 && (
              <div className="step-content">
                {/* Add content for Buyer's Step 2 here */}
              </div>
            )}
          </div>
          <div className="step" onClick={() => toggleStep('step3')}>
            <div className="step-header">
              <h3>Buyer Step-3</h3>
              <span className={`arrow ${isOpen.step3 ? 'open' : 'close'}`}></span>
            </div>
            {isOpen.step3 && (
              <div className="step-content">
                <p>
                  After making the full payment, you will need to provide us with a Gmail
                  account to which the channel will be transferred. We will then begin
                  the process of transferring the channel to the provided Gmail
                  account. Once the transfer is complete and you have been granted
                  access to the channel, you can start managing and customizing it
                  according to your preferences. It's recommended to review the
                  channel's content and analytics data to better understand its
                  audience and performance history and develop a strategy for growing
                  and expanding the channel in the future.
                </p>
              </div>
            )}
          </div>
        </>
      );
    } else {
      return (
        <>
          <div className="step" onClick={() => toggleStep('step1')}>
            <div className="step-header">
              <h3>Seller Step-1</h3>
              <span className={`arrow ${isOpen.step1 ? 'open' : 'close'}`}></span>
            </div>
            {isOpen.step1 && (
              <div className="step-content">
                {/* Add content for Seller's Step 1 here */}
              </div>
            )}
          </div>
          <div className="step" onClick={() => toggleStep('step2')}>
            <div className="step-header">
              <h3>Seller Step-2</h3>
              <span className={`arrow ${isOpen.step2 ? 'open' : 'close'}`}></span>
            </div>
            {isOpen.step2 && (
              <div className="step-content">
                {/* Add content for Seller's Step 2 here */}
              </div>
            )}
          </div>
          <div className="step" onClick={() => toggleStep('step3')}>
            <div className="step-header">
              <h3>Seller Step-3</h3>
              <span className={`arrow ${isOpen.step3 ? 'open' : 'close'}`}></span>
            </div>
            {isOpen.step3 && (
              <div className="step-content">
                {/* Add content for Seller's Step 3 here */}
              </div>
            )}
          </div>
        </>
      );
    }
  };

  return (
    <div className="process-container">
      <h2>Process</h2>
      <div className="buttons">
        <button
          className={`button ${selectedCategory === 'buyers' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('buyers')}
        >
          FOR BUYERS
        </button>
        <button
          className={`button ${selectedCategory === 'sellers' ? 'active' : ''}`}
          onClick={() => handleCategoryChange('sellers')}
        >
          FOR SELLERS
        </button>
      </div>
      <div className="steps">
        {renderSteps()}
      </div>
    </div>
  );
};

export default Process;
