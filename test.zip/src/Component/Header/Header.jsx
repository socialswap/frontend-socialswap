import React from 'react';
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const navigate = useNavigate();

  return (
    <header className="flex justify-between items-center p-4 bg-white">
      {/* Uncomment and add the correct path to your logo */}
      {/* <img src={logo} alt="ChannelKart Logo" className="h-10" /> */}
      <nav>
        <ul className="flex space-x-4">
          <li><button onClick={() => navigate("/")}>Home</button></li>
          <li><button onClick={() => navigate("/buy")}>Buy Channel</button></li>
          <li><button onClick={() => navigate("/how-to")}>How To</button></li>
          <li><button onClick={() => navigate("/grow")}>Grow Channel</button></li>
          <li><button onClick={() => navigate("/blogs")}>Blogs</button></li>
          <li><button onClick={() => navigate("/about")}>About</button></li>
          <li>
            <button 
              onClick={() => navigate("/sell")} 
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              Sell Channel
            </button>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
