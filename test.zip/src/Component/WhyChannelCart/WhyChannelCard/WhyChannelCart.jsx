import React from 'react';

const FeatureCard = ({ icon, title, description }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <div className="text-center mb-4">
      <img src={icon} alt={title} className="w-16 h-16 mx-auto" />
    </div>
    <h3 className="text-xl font-semibold text-center mb-2 text-blue-600">{title}</h3>
    <p className="text-gray-600 text-center">{description}</p>
  </div>
);

const WhyChannelKart = () => {
  const features = [
    {
      icon: "/path-to-verified-icon.svg",
      title: "Verified Listings",
      description: "At Channelkart, we take the authenticity and reliability of the properties we list for sale seriously. Our team thoroughly examines and verifies all YouTube channels before they are made available on our marketplace."
    },
    {
      icon: "/path-to-secure-icon.svg",
      title: "Safe & Secure Deals",
      description: "For us the trust of our customers is utmost priority and we take it very seriously. We use all possible means to make the each and every deal smooth and fully secured for both the buyer and seller."
    },
    {
      icon: "/path-to-easy-process-icon.svg",
      title: "Easy Process",
      description: "At our company, we make the process of buying and selling as seamless as possible. Our user-friendly platform and dedicated support team are always on hand to assist you every step of the way."
    },
    {
      icon: "/path-to-valuation-icon.svg",
      title: "Free Valuation",
      description: "Maximize the value of your channel with the help of our expert team. With years of experience and expertise, our team is dedicated to providing you with the best possible valuation of your channel. We consider all important factors while evaluating your channel."
    },
    {
      icon: "/path-to-track-record-icon.svg",
      title: "Proven Track Record",
      description: "Experience the power of a proven platform. With over 2000 content creators having already made successful deals on our marketplace, you can trust that our platform has a solid track record of facilitating safe and secure transactions."
    },
    {
      icon: "/path-to-help-desk-icon.svg",
      title: "Help Desk",
      description: "Our expert customer support team is dedicated to helping you navigate the buying and selling process. Available to assist you with any queries, our team is committed to providing you with the best possible service by making your journey more smooth."
    }
  ];

  return (
    <div className="bg-gray-100 py-16 px-4 sm:px-6 lg:px-8">
      <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Why ChannelKart?</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <FeatureCard key={index} {...feature} />
        ))}
      </div>
    </div>
  );
};

export default WhyChannelKart;