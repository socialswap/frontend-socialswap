import React from 'react';
// import youtubeImage from './youtube-image.png'; // Add your YouTube-related image

const Hero = () => (
  <div className="flex justify-between items-center p-12 bg-gray-100">
    <div className="w-1/2">
      <h1 className="text-4xl font-bold mb-4">
        The Most Trusted Platform to
        <br />
        <span className="text-blue-600">Buy & Sell</span> Established
        <br />
        Youtube Channel
      </h1>
      <div className="space-x-4">
        <button className="bg-blue-600 text-white px-6 py-2 rounded">BUY CHANNEL</button>
        <button className="bg-blue-600 text-white px-6 py-2 rounded">SELL CHANNEL</button>
      </div>
    </div>
    <div className="w-1/2">
      <img src='' alt="YouTube Channel Illustration" className="w-full" />
    </div>
  </div>
);

export default Hero;