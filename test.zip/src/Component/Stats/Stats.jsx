import React from 'react';

const StatItem = ({ icon, number, text }) => (
  <div className="flex items-center space-x-2">
    <div className="text-3xl">{icon}</div>
    <div>
      <div className="text-2xl font-bold">{number}</div>
      <div>{text}</div>
    </div>
  </div>
);

const Stats = () => (
  <div className="flex justify-around p-8 bg-white">
    <StatItem icon="📊" number="52+" text="Available Channels" />
    <StatItem icon="🤝" number="2000+" text="Happy Customers" />
    <StatItem icon="📅" number="5+" text="Years Of Business" />
  </div>
);

export default Stats;