import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './Component/Header/Header';
import Hero from './Component/Hero/Hero';
import Stats from './Component/Stats/Stats';
import Footer from './Component/Footer/Footer';
import FeaturedListings from './Component/Feature/Feature';
import LandingPages from './Pages/LandingPage/LandingPages';

const App = () => {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/" element={<LandingPages />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/features" element={<FeaturedListings />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
